-- MySQL dump 10.13  Distrib 5.7.30, for Linux (x86_64)
--
-- Host: localhost    Database: admin_dupak_basarnas
-- ------------------------------------------------------
-- Server version	5.7.30-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `admin_dupak_basarnas`
--


--
-- Table structure for table `tbl_butir`
--

DROP TABLE IF EXISTS `tbl_butir`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_butir` (
  `idButir` int(11) NOT NULL AUTO_INCREMENT,
  `idSubunsur` int(11) DEFAULT NULL,
  `namaButir` varchar(255) NOT NULL,
  PRIMARY KEY (`idButir`),
  KEY `tbl_butir_ibfk_1` (`idSubunsur`),
  CONSTRAINT `tbl_butir_ibfk_1` FOREIGN KEY (`idSubunsur`) REFERENCES `tbl_subunsur` (`idSubunsur`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_butir`
--

LOCK TABLES `tbl_butir` WRITE;
/*!40000 ALTER TABLE `tbl_butir` DISABLE KEYS */;
INSERT INTO `tbl_butir` VALUES (1,4,'Mengikuti pelatihan dibidang pertolongan dan pencarian'),(2,3,'Pembuatan karya inovasi'),(3,1,'Mengikuti Pendidikan Sekolah Dan Memperoleh Ijazah / Gelar'),(4,2,'Mengikuti Pendidikan Dan Pelatihan Teknis/fungsional Rescuer Serta Memperoleh Surat Tanda Tamat Pendidikan Dan Pelatihan (sttp)'),(5,2,'Pelaksanaan'),(11,12,'Mengikuti Pendidikan Dan Pelatihan Prajabatan'),(12,5,'Menyusun Rencana Dan Program'),(13,5,'Mengidentifikasi Daerah Rawan Musibah/bencana Dan Penyusunan Rencana Aksi Sar'),(14,5,'Menginventarisir Potensi Sar (1)'),(15,13,'Siaga Sar Rutin'),(16,13,'Siaga Sar Khusus'),(17,13,'Melaksanaan Kesamaptaan Jasmani'),(18,13,'Melaksanakan Keterampilan Sar'),(19,13,'Melaksanakan Latihan Sar'),(20,13,'Pemeliharaan Peralatan Sar'),(21,14,'Merencanakan Dan Mempersiapkan Pelaksanaan Operasi Sar'),(22,14,'Tindak Awal Operasi Sar'),(23,14,'Melaksanakan Operasi Sar'),(24,14,'Melakukan Pelaksanaan Evakuasi Korban'),(25,15,'Penyelenggaraan Operasi Sar (2)'),(26,16,'Karya Inovasi Hasil Penelitian/pengkajian/survei/evaluasi Di Bidang Pencarian Dan Pertolongan Yang Dipublikasikan'),(27,16,'Karya Inovasi Hasil Penelitian / Pengkajian / Survey / Evaluasi Di Bidang Pencarian Dan Pertolongan Yang Tidak Dipublikasikan, T'),(28,16,'Makalah Berupa Tinjauan Atau Ulasan Karya Inovasi Hasil Gagasan Sendiri Dalam Bidang Pencarian Dan Pertolongan Yang Tidak Dipubl'),(29,16,'Tulisan Karya Inovasi Populer Di Bidang Pencarian Dan Pertolongan Yang Disebarluaskan Melalui Media Massa Yang Merupakan Satu Ke'),(30,16,'Menyampaikan Prasaran Berupa Tinjauan, Gagasan, Atau Ulasan Ilmiah Dalam Pertemuan Ilmiah Nasional (tidak Harus Memberikan Rekom'),(31,17,'Alih Bahasa/saduran Di Bidang Pencarian Dan Pertolongan Yang 0 Dipublikasikan'),(32,17,'Alih Bahasa/saduran Di Bidang Pencarian Dan Pertolongan Yang  Dipublikasikan'),(33,18,'Menyusun Dan Atau Menyempurnakan Standar Bidang Pencarian Dan Pertolongan'),(34,18,'Menyusun Dan Atau Penyempurnakan Pedoman Pencarian Dan 0 Pertolongan'),(35,18,'Menyusun Dan Atau Menyempurnakan Petunjuk Teknis Pencarian Dan Pertolongan'),(36,19,'Menjadi Pengajar/ Pelatih Di Bidang Pencarian Dan Pertolongan Pada 0 Tingkat'),(37,20,'Mengikuti Seminar/lokakarya Dan Berperan Sebagai :'),(38,21,'Menjadi Anggota Organisasi Profesi Sebagai :'),(39,22,'Keanggotaan Sebagai Tim Penilai Atau Sebagai Tim Teknis Secara Aktif (dupak)'),(40,23,'Memperoleh Penghargaan/ Tanda Jasa Satya Lencana Karya Satya'),(41,2,'Ok');
/*!40000 ALTER TABLE `tbl_butir` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_butir_kegiatan`
--

DROP TABLE IF EXISTS `tbl_butir_kegiatan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_butir_kegiatan` (
  `idButirKegiatan` int(11) NOT NULL AUTO_INCREMENT,
  `idButir` int(11) DEFAULT NULL,
  `keterangan` varchar(255) NOT NULL,
  `point` float NOT NULL,
  PRIMARY KEY (`idButirKegiatan`),
  KEY `tbl_butir_kegiatan_ibfk_1` (`idButir`),
  CONSTRAINT `tbl_butir_kegiatan_ibfk_1` FOREIGN KEY (`idButir`) REFERENCES `tbl_butir` (`idButir`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_butir_kegiatan`
--

LOCK TABLES `tbl_butir_kegiatan` WRITE;
/*!40000 ALTER TABLE `tbl_butir_kegiatan` DISABLE KEYS */;
INSERT INTO `tbl_butir_kegiatan` VALUES (1,4,'Lamanya Lebih Dari 960 Jam',15),(2,4,'Lamanya 641 - 960 Jam',9),(8,4,'Lamanya 481 - 640 Jam',6),(9,4,'Lamanya 161 - 480 Jam',3),(10,4,'Lamanya 81-160 Jam',2),(11,4,'Lamanya 30-80 Jam',1),(12,4,'Lamanya 10-29 Jam',0.25),(13,11,'Pendidikan Dan Pelatihan Prajabatan Golongan Ii',1),(14,3,'Smu/smk/sederajat',1),(15,3,'Diploma 2',2),(16,3,'Diploma 3',4),(17,12,'Menyusun Kegiatan Latihan Sar Untuk',0),(18,12,'Menyusun Kegiatan Pemeliharaan Peralatan Sar Untuk',0),(19,13,'-',0),(20,14,'Mengiventarisasi Potensi Sar',0.009),(21,15,'Melaksanakan Siaga Sar Rutin 24 Jam',0.014),(22,15,'Melaksanakan Siaga Sar Rutin 12 Jam (08.00 - 20.00)',0.007),(23,16,'Melaksanakan Siaga Sar Rutin 12 Jam (20.00 - 08.00)',0.007),(24,16,'Melaksanakan Siaga Sar Khusus',0.025),(25,17,'Melakukan Latihan Fisik',0.004),(26,17,'Mengikuti Tes Fisik',0.008),(27,18,'Mengikuti Pembelajaran Teori Sebagai',0),(28,18,'Melakukan Praktek/aplikasi Sebagai :',0),(29,19,'Melaksanakan Latihan Kering Sebagai',0),(30,19,'Melaksanakan Latihan Basah/maneuver Sebagai',0),(31,20,'Melakukan Pemeliharaan Peralatan Vertical/high Risk Rescue',0.008),(32,20,'Melakukan Pemeliharaan Peralatan Sar Air',0.011),(33,20,'Melakukan Pemeliharaan Peralatan Ekstrikasi',0.015),(34,20,'Melakukan Pemeliharaan Peralatan Rapid Land Sar',0.014),(35,21,'-',0),(36,22,'Tindak Awal Operasi Sar',0.009),(37,23,'Melaksanakan Operasi Sar',0.012),(38,24,'Melakukan Pelaksanaan Evakuasi Korban',0.026),(39,25,'-',0),(40,26,'Dalam Bentuk Buku Yang Diterbitkan Dan Diedarkan Secara Nasional',0.1),(41,26,'Dalam Bentuk Majalah Ilmiah Yang Diakui Oleh Kementerian Yang Bersangkutan',0),(42,27,'Dalam Bentuk Buku Yang Diterbitkan Dan Diedarkan Secara Nasional',0.1),(43,26,'Dalam Bentuk Majalah Ilmiah Yang Diakui Oleh Kementerian Yang Bersangkutan',0),(44,28,'Dalam Bentuk Buku',0.1),(45,28,'Dalam Majalah',0),(46,29,'Tulisan Karya Inovasi Populer Di Bidang Pencarian Dan Pertolongan Yang Disebarluaskan Melalui Media Massa Yang Merupakan Satu Ke',0),(47,30,'Menyampaikan Prasaran Berupa Tinjauan, Gagasan, Atau Ulasan Ilmiah Dalam Pertemuan Ilmiah Nasional (tidak Harus Memberikan Rekom',0),(48,31,'Dalam Bentuk Buku Yang Diterbitkan Dan Diedarkan Secara Nasional',0.1),(49,31,'Dalam Bentuk Majalah Ilmiah Tingkat Nasional',0),(50,32,'Dalam Bentuk Buku',0.1),(51,32,'Dalam Bentuk Majalah Yang Diakui Oleh Instansi Yang Berwenang',0),(52,36,'Menjadi Pengajar/ Pelatih Di Bidang Pencarian Dan Pertolongan 0 Pada Tingkat Nasional',0),(53,36,'Menjadi Pengajar/ Pelatih Di Bidang Pencarian Dan Pertolongan Pada Tingkat Internasiona',0),(54,37,'Pemrasaran/penyaji/narasumber',0),(55,37,'Pembahas/moderator',0),(56,37,'Peserta',0),(57,38,'Ketua',0),(58,38,'Ketua',0),(59,40,'30 (tiga Puluh) Tahun',3),(60,40,'20 (dua Puluh) Tahun',2),(61,40,'10 (sepuluh) Tahun',1);
/*!40000 ALTER TABLE `tbl_butir_kegiatan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_divisi`
--

DROP TABLE IF EXISTS `tbl_divisi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_divisi` (
  `idDivisi` int(11) NOT NULL AUTO_INCREMENT,
  `namaDivisi` char(18) DEFAULT NULL,
  PRIMARY KEY (`idDivisi`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_divisi`
--

LOCK TABLES `tbl_divisi` WRITE;
/*!40000 ALTER TABLE `tbl_divisi` DISABLE KEYS */;
INSERT INTO `tbl_divisi` VALUES (16,'Analis Edit');
/*!40000 ALTER TABLE `tbl_divisi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_dokumen_kegiatan`
--

DROP TABLE IF EXISTS `tbl_dokumen_kegiatan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_dokumen_kegiatan` (
  `idDokumenKegiatan` int(11) NOT NULL AUTO_INCREMENT,
  `idKegiatanHarian` int(11) NOT NULL,
  `path_surat_kegiatan` varchar(255) NOT NULL,
  `path_laporan_kegiatan` varchar(255) NOT NULL,
  `path_dokumentasi` varchar(255) NOT NULL,
  `path_daftar_hadir` varchar(255) NOT NULL,
  `path_jurnal` varchar(255) NOT NULL,
  `path_sprint_siaga` varchar(255) NOT NULL,
  `path_check_peralatan` varchar(255) NOT NULL,
  PRIMARY KEY (`idDokumenKegiatan`),
  KEY `idKegiatanHarian` (`idKegiatanHarian`),
  CONSTRAINT `tbl_dokumen_kegiatan_ibfk_1` FOREIGN KEY (`idKegiatanHarian`) REFERENCES `tbl_kegiatan_harian` (`idKegiatanHarian`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_dokumen_kegiatan`
--

LOCK TABLES `tbl_dokumen_kegiatan` WRITE;
/*!40000 ALTER TABLE `tbl_dokumen_kegiatan` DISABLE KEYS */;
INSERT INTO `tbl_dokumen_kegiatan` VALUES (4,6,'SP_20200408071036.pdf','SP_202004080710361.pdf','SP_20200408071036.docx','','','',''),(5,9,'SP_20200408071313.pdf','SP_202004080713132.pdf','SP_202004080713131.pdf','','','',''),(6,10,'SP_20200408094256.pdf','SP_202004080942561.pdf','SP_20200408094256.jpg','','','',''),(7,11,'SP_20200409031714.pdf','SP_202004090317142.pdf','SP_202004090317141.pdf','','','',''),(8,12,'SP_20200411104100.pdf','SP_202004111041001.pdf','SP_20200411104100.jpg','','','',''),(9,13,'SP_20200413112047.pdf','SP_202004131120471.pdf','SP_20200413112047.jpeg','','','',''),(10,14,'SP_20200413060306.pdf','SP_202004130603062.pdf','SP_202004130603061.pdf','','','',''),(11,15,'SP_20200413060356.pdf','SP_202004130603561.pdf','SP_20200413060356.png','','','',''),(12,22,'SP_20200424103207.pdf','SP_202004241032071.pdf','SP_20200424103207.png','','','',''),(13,16,'SP_20200425044252.pdf','SP_202004250442521.pdf','SP_20200425044252.png','','','',''),(14,23,'SP_20200425121542.pdf','SP_202004251215421.pdf','SP_20200425121542.jpg','','','',''),(15,25,'SP_20200426014247.pdf','SP_202004260142471.pdf','SP_20200426014247.png','','','',''),(16,26,'SP_20200428074430.pdf','SP_202004280744301.pdf','SP_20200428074430.png','','','',''),(17,27,'SP_20200428081307.pdf','SP_202004280813071.pdf','SP_20200428081307.png','','','',''),(18,28,'SP_20200428085501.pdf','SP_202004280855011.pdf','SP_20200428085501.png','','','',''),(19,29,'SP_20200428090328.pdf','SP_202004280903281.pdf','SP_20200428090328.png','','','',''),(20,21,'SP_20200511022343.pdf','SP_202005110223431.pdf','SP_20200511022343.jpg','','','',''),(21,30,'SP_20200511022527.pdf','SP_202005110225271.pdf','SP_20200511022527.jpg','','','',''),(22,31,'SP_20200511043835.pdf','SP_202005110438351.pdf','SP_20200511043835.jpg','','','',''),(23,32,'SP_20200511044325.pdf','SP_202005110443251.pdf','SP_20200511044325.jpg','','','',''),(24,17,'SP_20200601101544.pdf','SP_202006011015441.pdf','SP_20200601101544.png','SP_202006011015442.pdf','SP_202006011015443.pdf','SP_202006011015444.pdf','SP_202006011015445.pdf'),(25,24,'SP_20200601104437.pdf','SP_202006011044371.pdf','SP_20200601104437.png','SP_202006011044372.pdf','SP_202006011044373.pdf','SP_202006011044374.pdf','SP_202006011044375.pdf'),(26,33,'SP_20200607094905.pdf','SP_202006070949051.pdf','SP_20200607094905.png','SP_202006070949052.pdf','SP_202006070949053.pdf','SP_202006070949054.pdf','SP_202006070949055.pdf'),(27,38,'SP_20200624051246.pdf','SP_202006240512461.pdf','SP_20200624051246.png','SP_202006240512462.pdf','SP_202006240512463.pdf','SP_202006240512464.pdf','SP_202006240512465.pdf'),(28,39,'SP_20200713124220.pdf','SP_202007131242201.pdf','SP_20200713124220.jpg','SP_202007131242202.pdf','SP_202007131242203.pdf','SP_202007131242204.pdf','SP_202007131242205.pdf'),(29,42,'SP_20200721101051.pdf','SP_202007211010511.pdf','SP_20200721101051.jpg','SP_202007211010512.pdf','SP_202007211010513.pdf','SP_202007211010514.pdf','SP_202007211010515.pdf'),(30,43,'SP_20200721102718.pdf','SP_202007211027181.pdf','SP_20200721102718.png','SP_202007211027182.pdf','SP_202007211027183.pdf','SP_202007211027184.pdf','SP_202007211027185.pdf'),(31,44,'SP_20200721103855.pdf','SP_202007211038551.pdf','SP_20200721103855.png','SP_202007211038552.pdf','SP_202007211038553.pdf','SP_202007211038554.pdf','SP_202007211038555.pdf'),(32,44,'SP_20200721105904.pdf','SP_202007211059041.pdf','SP_20200721105904.jpg','SP_202007211059042.pdf','SP_202007211059043.pdf','SP_202007211059044.pdf','SP_202007211059045.pdf');
/*!40000 ALTER TABLE `tbl_dokumen_kegiatan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_jabatan`
--

DROP TABLE IF EXISTS `tbl_jabatan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_jabatan` (
  `idJabatan` int(11) NOT NULL AUTO_INCREMENT,
  `namaJabatan` varchar(45) DEFAULT NULL,
  `tbl_pangkat_idPangkat` int(11) DEFAULT NULL,
  PRIMARY KEY (`idJabatan`),
  KEY `fk_tbl_jabatan_tbl_pangkat_idx` (`tbl_pangkat_idPangkat`),
  CONSTRAINT `fk_tbl_jabatan_tbl_pangkat` FOREIGN KEY (`tbl_pangkat_idPangkat`) REFERENCES `tbl_pangkat` (`idPangkat`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_jabatan`
--

LOCK TABLES `tbl_jabatan` WRITE;
/*!40000 ALTER TABLE `tbl_jabatan` DISABLE KEYS */;
INSERT INTO `tbl_jabatan` VALUES (11,'Penata Muda Tk. I (iii/b)',6),(12,'Penata Muda Tk. I (iii/b)',9),(14,'Pengatur Muda Tk. I (ii/b)',6),(16,'Penata Muda (iii/a)',5),(40,'Pengatur Tk. I (ii/d)',11),(42,'Pengatur Tk. I (ii/d)',15),(43,'Pengatur Tk. I (ii/d)',16),(44,'Penata Muda (iii/a)',17),(45,'Pengatur (ii/c)',17),(46,'Pengatur Muda Tk. I (ii/b)',17),(47,'Pengatur Muda (ii/a)',17),(48,'Penata Muda Tk. I (iii/b)',18),(49,'Penata Muda Tk. I (iii/b)',19),(50,'Penata Muda Tk. I (iii/b)',20),(51,'Penata Muda Tk. I (iii/b)',21),(52,'Penata Muda (iii/a)',21),(53,'Penata Muda Tk. I (iii/b)',22),(54,'Pengatur (ii/c)',23),(55,'Pengatur Tk. I (ii/d)',24),(56,'Penata Muda Tk. I  (iii/b)',25),(60,'Penata (iii/c)',27),(62,'Penata (iii/c)',31),(63,'Penata Muda Tk. I (iii/b)',32),(64,'Penata Muda Tk. I (iii/b)',33),(65,'Penata (iii/c)',21),(66,'Penata Muda (iii/a)',34),(67,'Pengatur Tk. I (ii/d)',17),(68,'Pengatur Muda Tk. I (ii/b)',35);
/*!40000 ALTER TABLE `tbl_jabatan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_jenjang`
--

DROP TABLE IF EXISTS `tbl_jenjang`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_jenjang` (
  `idJenjang` int(11) NOT NULL AUTO_INCREMENT,
  `namaJenjang` varchar(255) NOT NULL,
  PRIMARY KEY (`idJenjang`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_jenjang`
--

LOCK TABLES `tbl_jenjang` WRITE;
/*!40000 ALTER TABLE `tbl_jenjang` DISABLE KEYS */;
INSERT INTO `tbl_jenjang` VALUES (1,'Pemula'),(10,'Terampil (pelaksana)'),(14,'Mahir (pelaksana Lanjutan)'),(19,'Penyelia');
/*!40000 ALTER TABLE `tbl_jenjang` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_kegiatan_harian`
--

DROP TABLE IF EXISTS `tbl_kegiatan_harian`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_kegiatan_harian` (
  `idKegiatanHarian` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `idJenjang` int(11) NOT NULL,
  `idUnsur` int(11) NOT NULL,
  `idSubunsur` int(11) NOT NULL,
  `idButir` int(11) NOT NULL,
  `butirKegiatan` json NOT NULL,
  `tanggalMulai` date NOT NULL,
  `tanggalSelesai` date NOT NULL,
  `status` enum('Belum Upload Bukti','Diajukan','Diterima','Ditolak','Kadaluarsa','Belum diajukan') NOT NULL,
  `catatan` text NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`idKegiatanHarian`),
  KEY `idButir` (`idButir`),
  KEY `idJenjang` (`idJenjang`),
  KEY `idUnsur` (`idUnsur`),
  KEY `idSubunsur` (`idSubunsur`),
  KEY `userId` (`userId`),
  CONSTRAINT `tbl_kegiatan_harian_ibfk_1` FOREIGN KEY (`idButir`) REFERENCES `tbl_butir` (`idButir`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `tbl_kegiatan_harian_ibfk_2` FOREIGN KEY (`idJenjang`) REFERENCES `tbl_jenjang` (`idJenjang`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `tbl_kegiatan_harian_ibfk_3` FOREIGN KEY (`idUnsur`) REFERENCES `tbl_unsur` (`idUnsur`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `tbl_kegiatan_harian_ibfk_4` FOREIGN KEY (`idSubunsur`) REFERENCES `tbl_subunsur` (`idSubunsur`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `tbl_kegiatan_harian_ibfk_5` FOREIGN KEY (`userId`) REFERENCES `tbl_users` (`userId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_kegiatan_harian`
--

LOCK TABLES `tbl_kegiatan_harian` WRITE;
/*!40000 ALTER TABLE `tbl_kegiatan_harian` DISABLE KEYS */;
INSERT INTO `tbl_kegiatan_harian` VALUES (4,61,1,2,2,4,'[1, 2]','2020-04-13','2020-04-30','Diajukan','ok','0000-00-00 00:00:00','0000-00-00 00:00:00'),(5,61,1,2,2,4,'[1, 2]','2020-06-01','2020-06-03','Ditolak','ok','0000-00-00 00:00:00','0000-00-00 00:00:00'),(6,61,1,2,2,4,'[1, 2]','2020-04-05','2020-04-06','Diterima','ok','0000-00-00 00:00:00','0000-00-00 00:00:00'),(7,61,1,2,2,4,'[1, 2]','2020-04-07','2020-04-08','Diterima','ok','0000-00-00 00:00:00','0000-00-00 00:00:00'),(8,61,1,2,2,4,'[1, 2]','2020-04-08','2020-04-09','Kadaluarsa','ok','0000-00-00 00:00:00','0000-00-00 00:00:00'),(9,61,1,2,2,4,'[1, 2]','2020-04-10','2020-04-11','Diterima','ok','0000-00-00 00:00:00','0000-00-00 00:00:00'),(10,61,1,2,2,4,'[1, 2]','2020-04-03','2020-04-04','Diterima','ok','0000-00-00 00:00:00','0000-00-00 00:00:00'),(11,61,1,2,2,4,'[1, 2]','2020-05-01','2020-05-07','Ditolak','ok','0000-00-00 00:00:00','0000-00-00 00:00:00'),(12,61,10,2,2,4,'[1, 2]','2020-05-12','2020-05-14','Ditolak','ok','0000-00-00 00:00:00','0000-00-00 00:00:00'),(13,61,1,2,2,4,'[1, 2]','2020-04-15','2020-04-16','Diterima','ok','0000-00-00 00:00:00','0000-00-00 00:00:00'),(14,61,1,2,2,4,'[1, 2]','2020-04-23','2020-04-24','Ditolak','ok','0000-00-00 00:00:00','0000-00-00 00:00:00'),(15,61,1,2,2,4,'[1, 2]','2020-04-08','2020-04-09','Ditolak','ok','0000-00-00 00:00:00','0000-00-00 00:00:00'),(16,61,1,2,2,4,'[1, 2]','2020-04-29','2020-05-01','Diterima','ok','0000-00-00 00:00:00','0000-00-00 00:00:00'),(17,61,1,2,2,4,'[1, 2]','2020-05-07','2020-05-06','Diterima','ok','0000-00-00 00:00:00','2020-06-01 15:15:44'),(21,61,1,2,2,4,'[1]','2020-04-08','2020-04-30','Diterima','ok','0000-00-00 00:00:00','2020-05-11 21:23:43'),(22,61,1,1,2,4,'[1, 2]','2020-04-10','2020-04-11','Diterima','ok','0000-00-00 00:00:00','0000-00-00 00:00:00'),(23,61,10,1,2,4,'[1]','2020-05-13','2020-05-15','Ditolak','ok','2020-04-25 05:12:44','2020-04-25 05:15:42'),(24,61,1,2,13,15,'[21]','2020-04-26','2020-04-27','Diterima','ok','2020-04-26 16:06:09','2020-06-01 15:44:37'),(25,61,1,3,16,27,'[42]','2020-04-03','2020-04-04','Diterima','ok','2020-04-26 18:42:18','2020-04-26 18:42:47'),(26,84,1,2,13,15,'[21, 22]','2020-04-08','2020-04-11','Diterima','ok','2020-04-29 00:44:00','2020-04-29 00:44:30'),(27,84,1,1,1,3,'[14, 15]','2020-05-05','2020-05-07','Diterima','ok','2020-04-29 00:53:15','2020-04-29 01:13:07'),(28,84,10,3,17,32,'[50]','2020-04-13','2020-04-09','Diterima','ok','2020-04-29 01:54:23','2020-04-29 01:55:01'),(29,84,1,1,1,3,'[14]','2020-04-10','2020-04-12','Ditolak','ok','2020-04-29 02:03:06','2020-04-29 02:03:28'),(30,61,1,2,14,23,'[37]','2020-05-19','2020-05-21','Diterima','ok','2020-05-11 21:16:18','2020-05-11 21:25:27'),(31,86,10,2,15,25,'[39]','2020-04-08','2020-04-09','Diterima','ok','2020-05-11 21:37:53','2020-05-11 21:38:35'),(32,86,1,1,1,3,'[16]','2020-04-24','2020-04-28','Diterima','ok','2020-05-11 21:42:24','2020-05-11 21:43:26'),(33,61,1,2,13,16,'[23]','2020-05-27','2020-05-27','Ditolak','ok','2020-05-30 17:55:44','2020-06-07 21:49:06'),(38,61,1,1,1,3,'[14]','2020-06-23','2020-06-30','Diterima','ok','2020-06-04 20:33:48','2020-06-24 12:12:46'),(39,61,1,2,13,15,'[22]','2020-06-23','2020-06-23','Ditolak','ok','2020-06-23 10:51:37','2020-07-13 12:42:20'),(40,142,1,2,13,15,'[22]','2020-06-24','2020-06-24','Belum Upload Bukti','ok','2020-06-24 09:24:52','2020-06-24 09:24:52'),(41,142,1,2,13,15,'[22]','2020-07-02','2020-07-02','Belum Upload Bukti','ok','2020-07-03 09:55:14','2020-07-03 09:55:14'),(42,61,1,2,13,15,'[22]','2020-07-13','2020-07-13','Diajukan','ok','2020-07-13 18:56:43','2020-07-21 10:10:51'),(43,61,1,1,1,3,'[14]','2020-07-03','2020-07-10','Diajukan','','2020-07-21 10:18:46','2020-07-21 10:27:18'),(44,61,1,1,2,4,'[1]','2020-07-27','2020-07-28','Diajukan','','2020-07-21 10:31:52','2020-07-21 10:59:05');
/*!40000 ALTER TABLE `tbl_kegiatan_harian` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_pangkat`
--

DROP TABLE IF EXISTS `tbl_pangkat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_pangkat` (
  `idPangkat` int(11) NOT NULL AUTO_INCREMENT,
  `namaPangkat` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idPangkat`),
  UNIQUE KEY `id_jabatan_UNIQUE` (`idPangkat`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_pangkat`
--

LOCK TABLES `tbl_pangkat` WRITE;
/*!40000 ALTER TABLE `tbl_pangkat` DISABLE KEYS */;
INSERT INTO `tbl_pangkat` VALUES (5,'Teknisi Alat Elektro Dan Komunikasi'),(6,'Petugas Operator Radio'),(9,'Analis Sar'),(11,'Petugas Medis'),(15,'Pengelola Peralatan Dan Logistik'),(16,'Pengelola Kendaraan Dinas'),(17,'Rescuer'),(18,'Pengelola Bmn'),(19,'Penata Laporan Keuangan Dan Sai'),(20,'Pengelola Kegiatan Dan Anggaran'),(21,'Analis Keuangan'),(22,'Analis Kepegawaian'),(23,'Arsiparis'),(24,'Pengelola Urusan Dalam'),(25,'Pejabat'),(27,'Kakansar'),(31,'Kaur Umum'),(32,'Kasi Operasi Dan Siaga Pencarian Dan Pertolon'),(33,'Kasi Sumber Daya Pencarian Dan Pertolongan'),(34,'Analisis Pencarian Dan Pertolongan'),(35,'Pengemudi');
/*!40000 ALTER TABLE `tbl_pangkat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_roles`
--

DROP TABLE IF EXISTS `tbl_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_roles` (
  `roleId` tinyint(4) NOT NULL AUTO_INCREMENT COMMENT 'role id',
  `role` varchar(50) NOT NULL COMMENT 'role text',
  PRIMARY KEY (`roleId`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_roles`
--

LOCK TABLES `tbl_roles` WRITE;
/*!40000 ALTER TABLE `tbl_roles` DISABLE KEYS */;
INSERT INTO `tbl_roles` VALUES (1,'superadmin'),(7,'Rescuer'),(18,'Atasan'),(19,'Tim Penilai');
/*!40000 ALTER TABLE `tbl_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_subunsur`
--

DROP TABLE IF EXISTS `tbl_subunsur`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_subunsur` (
  `idSubunsur` int(11) NOT NULL AUTO_INCREMENT,
  `idUnsur` int(11) DEFAULT NULL,
  `namaSubunsur` varchar(255) NOT NULL,
  PRIMARY KEY (`idSubunsur`),
  KEY `idUnsur` (`idUnsur`),
  CONSTRAINT `tbl_subunsur_ibfk_1` FOREIGN KEY (`idUnsur`) REFERENCES `tbl_unsur` (`idUnsur`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_subunsur`
--

LOCK TABLES `tbl_subunsur` WRITE;
/*!40000 ALTER TABLE `tbl_subunsur` DISABLE KEYS */;
INSERT INTO `tbl_subunsur` VALUES (1,1,'Pendidikan Sekolah Dan Mendapat Gelar'),(2,1,'Pendidikan Dan Pelatihan Teknis/fungsional Rescuer Serta Memperoleh Surat Tanda Tamat Pendidkan Dan Pelatihan (sttp)'),(3,3,'Pembuatan karya inovasi dibidang pencarian dan pertolongan'),(4,NULL,'Pelatihan dibidang pertolongan dan pencarian'),(5,2,'Persiapan'),(12,1,'Pendidikan Dan Pelatihan Prajabatan'),(13,2,'Kesiapsiagaan Sar'),(14,2,'Penyelenggaraan Operasi Sar'),(15,2,'Evaluasi Dan Laporan'),(16,3,'Pembuatan Karya Inovasi Di Bidang Pencarian Dan Pertolongan'),(17,3,'Penerjemahan/penyaduran Buku Dan Bahan-bahan Lain Di Bidang Pencarian Dan Pertolongan'),(18,3,'Penyusunan Ketentuan Pelaksanaan/ketentuan Teknis Di Bidang Pencarian Dan Pertolongan'),(19,20,'Pengajar/ Pelatih Di Bidang Pencarian Dan Pertolongan'),(20,20,'Peran Serta Dalam Seminar/ Loka Karya Di Bidang Pencarian Dan Pertolongan'),(21,20,'Keanggotaan Dalam Organisasi Profesi Rescuer'),(22,20,'Keanggotaan Dalam Tim Penilai'),(23,20,'Memperoleh Tanda Jasa/penghargaan'),(24,20,'Cuti/dinas Luar');
/*!40000 ALTER TABLE `tbl_subunsur` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_tokens`
--

DROP TABLE IF EXISTS `tbl_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_tokens` (
  `token_id` int(11) NOT NULL AUTO_INCREMENT,
  `token` longtext NOT NULL,
  `email` varchar(255) NOT NULL,
  `dateCreated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`token_id`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_tokens`
--

LOCK TABLES `tbl_tokens` WRITE;
/*!40000 ALTER TABLE `tbl_tokens` DISABLE KEYS */;
INSERT INTO `tbl_tokens` VALUES (6,'ztfDt7VC2jk8CsL3ihPG2ZuBsunbbx6IwiZX6uY0DlQ=','yogi@dib.biz.id','2020-04-23 08:49:58'),(8,'AyiRUGS8Wri2BnsTZAMPHUfKQs5aJ3rIpCmvqo8prLs=','david.rigan@students.amikom.ac.id','2020-04-23 09:07:56'),(13,'Se0lsIpl241WYSBESgYYNh5BJJX1qejkSIawq8Qwdsg=','david.rigan@students.amikom.ac.id','2020-04-23 09:28:32'),(14,'efwGloxtSSFYSi2+4OlFU4gr9auwzawfCQA6DgJsvRA=','david.rigan@students.amikom.ac.id','2020-04-23 09:47:10'),(23,'UpFRKWXSG45i22C7RKRpTw7nJh3MHgrCR0mXo3pIwks=','yogi.yulianto@students.amikom.ac.id','2020-04-23 16:18:36'),(24,'sDxGo5uEgVODoOxqpX+nGNbVRPPiSQvGKYNz6N+LLi8=','yogi.yulianto@students.amikom.ac.id','2020-04-23 16:20:37'),(41,'wG1iFSpQsPatggYJ/qvH+LVhKHcNtehG8HuZyzbMeRk=','Anjasmoro@jourrapide.com','2020-06-27 08:25:52');
/*!40000 ALTER TABLE `tbl_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_unsur`
--

DROP TABLE IF EXISTS `tbl_unsur`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_unsur` (
  `idUnsur` int(11) NOT NULL AUTO_INCREMENT,
  `namaUnsur` varchar(255) NOT NULL,
  PRIMARY KEY (`idUnsur`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_unsur`
--

LOCK TABLES `tbl_unsur` WRITE;
/*!40000 ALTER TABLE `tbl_unsur` DISABLE KEYS */;
INSERT INTO `tbl_unsur` VALUES (1,'PENDIDIKAN'),(2,'PENCARIAN DAN PERTOLONGAN'),(3,'PENGEMBANGAN PROFESI'),(20,'Penunjang');
/*!40000 ALTER TABLE `tbl_unsur` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_users`
--

DROP TABLE IF EXISTS `tbl_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_users` (
  `userId` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(128) NOT NULL COMMENT 'login email',
  `password` varchar(128) NOT NULL COMMENT 'login password md5',
  `name` varchar(128) DEFAULT NULL COMMENT 'full name of user',
  `mobile` varchar(20) DEFAULT NULL,
  `roleId` tinyint(4) DEFAULT NULL,
  `isDeleted` tinyint(4) NOT NULL DEFAULT '0',
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT NULL,
  `nip` char(18) DEFAULT NULL,
  `fotoProfil` varchar(255) DEFAULT NULL,
  `tbl_divisi_idDivisi` int(11) DEFAULT NULL,
  `tbl_jabatan_idJabatan` int(11) DEFAULT NULL,
  `nomorSeriKartuPegawai` varchar(30) NOT NULL,
  `tempatLahir` varchar(255) NOT NULL,
  `tanggalLahir` date NOT NULL,
  `pendidikan` enum('SD','SMP','SMA','D1','D2','D3','S1/D4','S2','S3') NOT NULL,
  `mulaiKerja` date NOT NULL,
  `jenisKelamin` enum('laki-laki','perempuan','','') NOT NULL,
  PRIMARY KEY (`userId`),
  UNIQUE KEY `email` (`email`),
  KEY `fk_tbl_users_tbl_divisi1_idx` (`tbl_divisi_idDivisi`),
  KEY `tbl_users_ibfk_1` (`roleId`),
  KEY `tbl_users_ibfk_2` (`tbl_jabatan_idJabatan`),
  CONSTRAINT `tbl_users_ibfk_1` FOREIGN KEY (`roleId`) REFERENCES `tbl_roles` (`roleId`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `tbl_users_ibfk_2` FOREIGN KEY (`tbl_jabatan_idJabatan`) REFERENCES `tbl_jabatan` (`idJabatan`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=177 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_users`
--

LOCK TABLES `tbl_users` WRITE;
/*!40000 ALTER TABLE `tbl_users` DISABLE KEYS */;
INSERT INTO `tbl_users` VALUES (61,'yogi@dib.biz.id','5621be1f2352574f7a48ba5596a7c69d','Yogi','0838635934',1,0,0,'0000-00-00 00:00:00',61,'2020-06-08 09:08:44','1221314213','1221314213_20200608090844.jpg',16,12,'YY180707','Semarang','1998-10-10','SMA','2010-10-10','laki-laki'),(62,'pandu@dib.biz.id','8acf7115033fa7bbfebe4b9b726ab374','Pandu','0838635934',7,1,61,'2020-04-01 18:45:24',61,'2020-04-05 09:20:04','1233445','1233445_20200403073311.jpg',16,12,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(64,'dupak@dib.biz.id','25f9e794323b453885f5181f1b624d0b','Budiyanto, S.e.','0897505400',7,1,61,'2020-04-02 10:59:33',61,'2020-04-05 09:20:12','1983052620','1983052620_20200403073557.gif',16,12,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(76,'yogid@gmai.com','938e14c074c45c62eb15cc05a6f36d79','David','0838635934',7,1,61,'2020-04-03 18:44:09',61,'2020-04-05 09:20:21','9975674435','9975674435_20200403064409.jpg',16,11,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(77,'david@gmail.com','172522ec1028ab781d9dfd17eaca4427','David','0838635934221',7,1,61,'2020-04-03 17:45:32',61,'2020-04-05 06:50:42','083863593422565768','0838635934_20200403054532.png',16,16,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(78,'adhellialaras@dib.biz.id','5b4b949c39b286bd9c8a308c7426a310','Adhellia Laras Tri Hastuti','08975054005',7,1,61,'2020-04-04 13:21:26',61,'2020-04-05 06:50:27','098765432123456789','0987654321234567890_20200404012126.png',16,16,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(79,'devry@dib.biz.id','938e14c074c45c62eb15cc05a6f36d79','Devry','083863593475',7,1,61,'2020-04-05 03:21:44',61,'2020-04-05 09:21:16','111111111111111111','1111111111111111111_20200405032144.png',16,NULL,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(80,'adhellia.19@gmail.com','5b4b949c39b286bd9c8a308c7426a310','Adhellia','08975054005',7,1,61,'2020-04-05 03:45:39',61,'2020-04-05 09:28:30','1234567890','1234567890_20200405034539.png',16,40,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(81,'adhel@gmail.com','adb8eaa8c58c0f40e8cb1bd8762de570','Adhellia Laras Tri Hastuti','08975054005',7,1,61,'2020-04-05 04:58:41',61,'2020-04-05 09:28:36','1234567890','1234567890_20200405045841.png',16,16,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(82,'adhel@gmail.id','25d55ad283aa400af464c76d713c07ad','Adhellia','08975054005',7,1,61,'2020-04-05 05:35:18',61,'2020-04-05 09:28:42','1234567890','1234567890_20200405053518.png',16,11,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(83,'adhellia@gmail.com','25d55ad283aa400af464c76d713c07ad','Adhellia','08975054004',7,1,61,'2020-04-05 05:43:19',61,'2020-04-05 09:28:47','123644','123644_20200405054319.png',16,40,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(84,'Anjasmoro@jourrapide.com','ed2b1f468c5f915f3f1cf75d7068baae','Anjasmoro Kurnia Adi, S.h.','0899555746',7,0,61,'2020-04-05 10:18:15',61,'2020-04-19 15:11:13','198805272010121002','198805272010121002_20200405101815.jpeg',16,12,'YY180707','Semarang','1998-10-10','SMA','2015-08-10','laki-laki'),(85,'budiyanto@jourrapide.com','adb8eaa8c58c0f40e8cb1bd8762de570','Budiyanto, S.e.','08785556422',7,0,61,'2020-04-05 10:46:55',85,'2020-06-08 08:59:46','198305262005021001','198305262005021001_20200405104655.jpeg',16,12,'KKHSDSDSA','Semarang','1998-10-10','D1','2010-10-10','laki-laki'),(86,'adebudi@jourrapide.com','adb8eaa8c58c0f40e8cb1bd8762de570','Ade Budi Nurcahyo','0898555311',7,0,61,'2020-04-05 10:49:15',NULL,NULL,'197406011997031001','197406011997031001_20200405104915.png',16,11,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(87,'nuristi@jourrapide.com','adb8eaa8c58c0f40e8cb1bd8762de570','Nur Isti Rahmawati','0838555191',7,0,61,'2020-04-05 10:51:16',NULL,NULL,'198908252010122003','198908252010122003_20200405105116.jpeg',16,14,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(88,'ayuwulandari@jourrapide.com','adb8eaa8c58c0f40e8cb1bd8762de570','Ayu Wulandari Henaulu','0878555052',7,0,61,'2020-04-05 10:53:03',NULL,NULL,'199203072010122001','199203072010122001_20200405105302.png',16,14,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(89,'marsudi@jourrapide.com','adb8eaa8c58c0f40e8cb1bd8762de570','Marsudi, S.t.','0812555667',7,0,61,'2020-04-05 10:58:03',NULL,NULL,'198003132007121001','198003132007121001_20200405105803.jpeg',16,16,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(90,'meinita@jourrapide.com','adb8eaa8c58c0f40e8cb1bd8762de570','Meinita Ari Prastiwi, A.md. Kep','0857555541',7,0,61,'2020-04-05 11:01:23',NULL,NULL,'198505222008122002','198505222008122002_20200405110123.jpg',16,40,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(91,'kristy@jourrapide.com','adb8eaa8c58c0f40e8cb1bd8762de570','Kristyanining, A.mk.','0813555955',7,0,61,'2020-04-05 11:06:26',NULL,NULL,'198410212009122003','198410212009122003_20200405110626.jpg',16,40,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(92,'fauzyfirman@jourrapide.com','adb8eaa8c58c0f40e8cb1bd8762de570','Fauzi Firmansyah, A.md.t.','0838555727',7,0,61,'2020-04-05 11:09:03',NULL,NULL,'197909242009121002','197909242009121002_20200405110903.JPG',16,42,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(93,'nugroho@jourrapide.com','adb8eaa8c58c0f40e8cb1bd8762de570','Nugroho Yuliatmoko','0899555399',7,0,61,'2020-04-05 11:10:57',61,'2020-04-05 11:11:23','198107112005021001','198107112005021001_20200405111123.jpg',16,43,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(94,'arifrahman@jourrapide.com','adb8eaa8c58c0f40e8cb1bd8762de570','Arif Rahman, A.md.','0838555576',7,0,61,'2020-04-05 11:13:18',NULL,NULL,'198101212005021001','198101212005021001_20200405111318.jpg',16,44,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(95,'nugrohoadi@jourrapide.com','adb8eaa8c58c0f40e8cb1bd8762de570','Nugroho Adi Wibowo Santoso','0878555913',7,0,61,'2020-04-05 11:15:10',NULL,NULL,'198603292005021001','198603292005021001_20200405111510.jpg',16,45,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(96,'sulisharyanto@jourrapide.com','adb8eaa8c58c0f40e8cb1bd8762de570','Sulis Haryanto','0878555692',7,0,61,'2020-04-05 11:18:16',NULL,NULL,'197609132006041002','197609132006041002_20200405111816.jpg',16,45,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(97,'dhediprasetya@jourrapide.com','adb8eaa8c58c0f40e8cb1bd8762de570','Dhedi Prasetya','0899555578',7,0,61,'2020-04-05 11:22:47',NULL,NULL,'198305072007121001','198305072007121001_20200405112247.jpg',16,45,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(98,'sunardi@jourrapide.com','adb8eaa8c58c0f40e8cb1bd8762de570','Sunardi','0896555614',7,0,61,'2020-04-05 11:26:08',NULL,NULL,'198503202007121003','198503202007121003_20200405112608.JPG',16,45,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(99,'maryadi@jourrapide.com','adb8eaa8c58c0f40e8cb1bd8762de570','Maryadi','0878555707',7,0,61,'2020-04-05 11:27:54',NULL,NULL,'198612092007121001','198612092007121001_20200405112754.jpg',16,45,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(100,'taufiqmujiono@jourrapide.com','adb8eaa8c58c0f40e8cb1bd8762de570','Taufiq Mujiono','0897555092',7,0,61,'2020-04-05 11:32:02',NULL,NULL,'198709102007121001','198709102007121001_20200405113202.jpeg',16,45,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(101,'prasetyautama@jourrapide.com','adb8eaa8c58c0f40e8cb1bd8762de570','Prasetya Utama','0818555031',7,0,61,'2020-04-05 11:35:28',NULL,NULL,'198502172008121001','198502172008121001_20200405113528.jpg',16,45,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(102,'hadikusnawan@jourrapide.com','adb8eaa8c58c0f40e8cb1bd8762de570','Hadi Kusnawan Widagdo','0852555719',7,0,61,'2020-04-05 11:37:12',NULL,NULL,'198511092008121001','198511092008121001_20200405113712.jpg',16,45,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(103,'setosatrio@jourrapide.com','adb8eaa8c58c0f40e8cb1bd8762de570','Seto Satrio Wicaksono','0857555720',7,0,61,'2020-04-05 11:38:59',NULL,NULL,'198610272008121001','198610272008121001_20200405113859.jpg',16,45,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(104,'dwiafandi@jourrapide.com','adb8eaa8c58c0f40e8cb1bd8762de570','Dwi Afandi Saputro','0838555559',7,0,61,'2020-04-05 11:41:08',NULL,NULL,'198703302008121001','198703302008121001_20200405114108.jpg',16,45,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(105,'ardiharyanto@jourrapide.com','adb8eaa8c58c0f40e8cb1bd8762de570','Ardi Haryanto','0878555922',7,0,61,'2020-04-05 11:43:47',NULL,NULL,'198710172008121001','198710172008121001_20200405114347.jpg',16,45,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(106,'elframyuliawan@jourrapide.com','adb8eaa8c58c0f40e8cb1bd8762de570','Elfram Yuliawan','0856555719',7,0,61,'2020-04-05 11:45:35',NULL,NULL,'198707212010122001','198707212010122001_20200405114535.jpg',16,45,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(107,'mushlih@jourrapide.com','adb8eaa8c58c0f40e8cb1bd8762de570','Muhammad Mushlih','0897555246',7,0,61,'2020-04-05 11:48:09',NULL,NULL,'198911172010121002','198911172010121002_20200405114809.JPG',16,45,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(108,'adifachroni@jourrapide.com','adb8eaa8c58c0f40e8cb1bd8762de570','Adi Fachroni Azis','0815555295',7,0,61,'2020-04-05 11:49:51',NULL,NULL,'198512112008121002','198512112008121002_20200405114951.jpg',16,46,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(109,'adityasumarsono@jourrapide.com','adb8eaa8c58c0f40e8cb1bd8762de570','Aditya Sumarsono','0898555119',7,0,61,'2020-04-05 11:51:19',NULL,NULL,'199009142008121001','199009142008121001_20200405115119.jpg',16,46,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(110,'trisno@jourrapide.com','adb8eaa8c58c0f40e8cb1bd8762de570','Trisno','0897555281',7,0,61,'2020-04-05 11:53:18',NULL,NULL,'198508032009121008','198508032009121008_20200405115318.jpg',16,46,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(111,'richa@jourrapide.com','adb8eaa8c58c0f40e8cb1bd8762de570','Richa Purnama Budi','0858555974',7,0,61,'2020-04-05 11:54:55',NULL,NULL,'198707112009122001','198707112009122001_20200405115455.jpg',16,46,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(112,'priaraharja@jourrapide.com','adb8eaa8c58c0f40e8cb1bd8762de570','Pria Raharja','0814555329',7,0,61,'2020-04-05 11:56:22',NULL,NULL,'198707122009121004','198707122009121004_20200405115622.jpg',16,46,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(113,'binaproklamanta@jourrapide.com','adb8eaa8c58c0f40e8cb1bd8762de570','Bina Proklamanta A','0813555299',7,0,61,'2020-04-05 11:57:59',NULL,NULL,'198708172009121003','198708172009121003_20200405115759.jpg',16,46,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(114,'rendralerry@jourrapide.com','adb8eaa8c58c0f40e8cb1bd8762de570','Rendra Lerry Prasetyas','0878555171',7,0,61,'2020-04-05 11:59:37',NULL,NULL,'198801182009121004','198801182009121004_20200405115937.jpg',16,46,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(115,'heriprasetyo@jourrapide.com','adb8eaa8c58c0f40e8cb1bd8762de570','Heri Prasetyo','0878555702',7,0,61,'2020-04-05 12:01:24',NULL,NULL,'198806082009121004','198806082009121004_20200405120124.jpg',16,46,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(116,'ekohandoyo@jourrapide.com','adb8eaa8c58c0f40e8cb1bd8762de570','Eko Handoyo','0898555134',7,0,61,'2020-04-05 12:02:55',NULL,NULL,'198811232009121001','198811232009121001_20200405120255.jpg',16,46,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(117,'yokimaulana@jourrapide.com','adb8eaa8c58c0f40e8cb1bd8762de570','Yoki Maolana','0817555297',7,0,61,'2020-04-05 12:04:23',NULL,NULL,'198811262009121004','198811262009121004_20200405120423.jpg',16,46,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(118,'agustinus@jourrapide.com','adb8eaa8c58c0f40e8cb1bd8762de570','Agustinus Danang Suranto','0878555720',7,0,61,'2020-04-05 12:05:49',NULL,NULL,'199008182009121003','199008182009121003_20200405120549.jpg',16,46,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(119,'giyong@jourrapide.com','adb8eaa8c58c0f40e8cb1bd8762de570','Giyong Widianto','0814555049',7,0,61,'2020-04-05 12:07:10',NULL,NULL,'198903182009121001','198903182009121001_20200405120710.jpg',16,46,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(120,'komunikatama@jourrapide.com','adb8eaa8c58c0f40e8cb1bd8762de570','Komunikatama Kanifann F.','0854555217',7,0,61,'2020-04-05 12:08:57',NULL,NULL,'199101012009121001','199101012009121001_20200405120857.jpg',16,46,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(121,'herujunaidi@jourrapide.com','adb8eaa8c58c0f40e8cb1bd8762de570','Heru Junaidi','0856555355',7,0,61,'2020-04-05 12:10:18',NULL,NULL,'198201292010121003','198201292010121003_20200405121018.png',16,46,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(122,'novikurnia@jourrapide.com','adb8eaa8c58c0f40e8cb1bd8762de570','Novi Kurnia','0838555748',7,0,61,'2020-04-05 12:11:48',NULL,NULL,'198711062010121001','198711062010121001_20200405121148.jpg',16,46,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(123,'pipiteriyanto@jourrapide.com','adb8eaa8c58c0f40e8cb1bd8762de570','Pipit Eriyanto','0897555635',7,0,61,'2020-04-05 12:13:13',NULL,NULL,'198805012010121002','198805012010121002_20200405121313.jpg',16,46,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(124,'agungbudi@jourrapide.com','adb8eaa8c58c0f40e8cb1bd8762de570','Agung Budi Wibowo','0815555746',7,0,61,'2020-04-05 12:14:32',NULL,NULL,'198912212010121001','198912212010121001_20200405121432.jpg',16,46,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(125,'bagusaditya@jourrapide.com','adb8eaa8c58c0f40e8cb1bd8762de570','Bagus Aditya','0898555026',7,0,61,'2020-04-05 12:16:19',NULL,NULL,'199003132010121001','199003132010121001_20200405121619.jpg',16,46,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(126,'rossywahyu@jourrapide.com','adb8eaa8c58c0f40e8cb1bd8762de570','Rossy Wahyu Arinta','0857555747',7,0,61,'2020-04-05 12:18:11',NULL,NULL,'199003212010122001','199003212010122001_20200405121811.jpg',16,46,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(127,'sigitharyanto@jourrapide.com','adb8eaa8c58c0f40e8cb1bd8762de570','Sigit Haryanto','0815555378',7,0,61,'2020-04-05 12:19:47',NULL,NULL,'199003232010121005','199003232010121005_20200405121947.jpg',16,46,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(128,'akhmadkuswanto@jourrapide.com','adb8eaa8c58c0f40e8cb1bd8762de570','Akhmad Kuswanto','0858555538',7,0,61,'2020-04-05 12:21:28',NULL,NULL,'199105252010121002','199105252010121002_20200405122128.jpeg',16,44,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(129,'asiatusaminiar@jourrapide.com','adb8eaa8c58c0f40e8cb1bd8762de570','Asiatus Aminiar','0878555783',7,0,61,'2020-04-05 12:23:01',NULL,NULL,'198901152009122002','198901152009122002_20200405122301.jpeg',16,47,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(130,'Nuwardidit@jourrapide.com','adb8eaa8c58c0f40e8cb1bd8762de570','Nuwardidit Prambudi','0838555949',7,0,61,'2020-04-05 12:27:18',NULL,NULL,'199001142015031005','199001142015031005_20200405122718.jpg',16,47,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(131,'danangaprianto@jourrapide.com','adb8eaa8c58c0f40e8cb1bd8762de570','Danang Aprianto Wibowo','0878555852',7,0,61,'2020-04-05 12:32:02',NULL,NULL,'199004112015031005','199004112015031005_20200405123202.jpg',16,47,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(132,'bayugesang@jourrapide.com','adb8eaa8c58c0f40e8cb1bd8762de570','Bayu Gesang Pamungkas','0878555202',7,0,61,'2020-04-05 12:33:36',NULL,NULL,'199101312015031003','199101312015031003_20200405123336.jpg',16,47,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(133,'robyfajar@jourrapide.com','adb8eaa8c58c0f40e8cb1bd8762de570','Roby Fajar Setyawan','0852555674',7,0,61,'2020-04-05 12:35:18',NULL,NULL,'199105292015031003','199105292015031003_20200405123518.jpg',16,47,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(134,'adiagung@jourrapide.com','adb8eaa8c58c0f40e8cb1bd8762de570','M. Adi Agung Suliestyo','0814555577',7,0,61,'2020-04-05 12:36:55',NULL,NULL,'199108272015031002','199108272015031002_20200405123655.jpg',16,47,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(135,'okifabrianto@jourrapide.com','adb8eaa8c58c0f40e8cb1bd8762de570','Oki Fabrianto','0814555412',7,0,61,'2020-04-05 12:38:18',NULL,NULL,'199110052015031004','199110052015031004_20200405123818.jpg',16,47,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(136,'denysukaryanto@jourrapide.com','adb8eaa8c58c0f40e8cb1bd8762de570','Deny Sukaryanto','0897555983',7,0,61,'2020-04-05 12:39:56',NULL,NULL,'199306122015031001','199306122015031001_20200405123956.jpg',16,47,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(137,'rinatri@jourrapide.com','adb8eaa8c58c0f40e8cb1bd8762de570','Rina Tri Handayani','0878555956',7,0,61,'2020-04-05 12:43:52',NULL,NULL,'199502132015032001','199502132015032001_20200405124352.jpeg',16,47,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(138,'muhammadadam@jourrapide.com','adb8eaa8c58c0f40e8cb1bd8762de570','Muhammad Adam','0838555879',7,0,61,'2020-04-05 12:45:33',NULL,NULL,'199505012015031001','199505012015031001_20200405124533.jpg',16,47,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(139,'rusyrosali@jourrapide.com','adb8eaa8c58c0f40e8cb1bd8762de570','Rusy Rosali','0856555800',7,0,61,'2020-04-05 12:47:00',NULL,NULL,'199507072015032001','199507072015032001_20200405124700.jpg',16,47,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(140,'faiqmasyhuri@jourrapide.com','adb8eaa8c58c0f40e8cb1bd8762de570','Faiq Masyhuri','0878555062',7,0,61,'2020-04-05 12:48:30',NULL,NULL,'199509012015031001','199509012015031001_20200405124830.jpg',16,47,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(141,'choirularifianto@jourrapide.com','adb8eaa8c58c0f40e8cb1bd8762de570','Choirul Arifianto','0898555973',7,0,61,'2020-04-05 12:50:04',NULL,NULL,'199509242015031001','199509242015031001_20200405125004.jpg',16,44,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(142,'suzanti@jourrapide.com','adb8eaa8c58c0f40e8cb1bd8762de570','Suzanti Indah Sari','0878555594',7,0,61,'2020-04-05 12:51:29',NULL,NULL,'199603032015032001','199603032015032001_20200405125129.jpg',16,47,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(143,'sidiqpanduardi@jourrapide.com','adb8eaa8c58c0f40e8cb1bd8762de570','Sidiq Panduardi','0838555029',7,0,61,'2020-04-05 12:53:47',NULL,NULL,'199607142015031001','199607142015031001_20200405125347.jpg',16,44,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(144,'rusliyudiyanti@jourrapide.com','adb8eaa8c58c0f40e8cb1bd8762de570','Rusli Yudiyanti, S.e.','0855555686',7,0,61,'2020-04-05 12:55:42',NULL,NULL,'197811132009122002','197811132009122002_20200405125542.jpeg',16,48,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(145,'desie@jourrapide.com','adb8eaa8c58c0f40e8cb1bd8762de570','Desie Zunita Fitriani, S.h.','0838555124',7,0,61,'2020-04-05 12:57:34',NULL,NULL,'198506172010122002','198506172010122002_20200405125734.jpeg',16,49,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(146,'okisatrio@jourrapide.com','adb8eaa8c58c0f40e8cb1bd8762de570','Oki Satrio Jati, S.h.','0853555204',7,0,61,'2020-04-05 12:59:09',NULL,NULL,'198110242009121001','198110242009121001_20200405125909.jpeg',16,50,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(147,'annawidiasari@jourrapide.com','adb8eaa8c58c0f40e8cb1bd8762de570','Anna Widiasari, S.e.','0898555564',7,0,61,'2020-04-05 13:00:57',NULL,NULL,'198108072009122002','198108072009122002_20200405010057.jpeg',16,51,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(148,'arianadinyati@jourrapide.com','adb8eaa8c58c0f40e8cb1bd8762de570','Ariana Dinyati, S.h. M.si. (han)','0878555640',7,0,61,'2020-04-05 13:02:58',61,'2020-04-24 08:17:54','198701092009122007','198701092009122007_20200424081754.png',16,51,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(149,'elhitprasetia@jourrapide.com','adb8eaa8c58c0f40e8cb1bd8762de570','Elhit Prasetia, S.e.','0878555045',7,0,61,'2020-04-05 13:06:24',61,'2020-04-24 08:15:39','199007022008121002','199007022008121002_20200424081539.jpg',16,52,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(150,'sutarjo@jourrapide.com','adb8eaa8c58c0f40e8cb1bd8762de570','Sutarjo','0838555291',7,0,61,'2020-04-05 13:08:01',61,'2020-04-24 08:18:09','196907121992031002','196907121992031002_20200424081809.png',16,53,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(151,'elvira@jourrapide.com','adb8eaa8c58c0f40e8cb1bd8762de570','Elvira Hermawati, A.md.','0838555979',7,0,61,'2020-04-05 13:09:59',61,'2020-04-24 08:18:25','199110162015032001','199110162015032001_20200424081825.png',16,54,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(152,'fitriana@jourrapide.com','adb8eaa8c58c0f40e8cb1bd8762de570','Fitriana, A.md.','0878555259',7,0,61,'2020-04-05 13:11:49',61,'2020-04-24 08:17:16','199304252015032002','199304252015032002_20200424081716.jpg',16,54,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(153,'nofyan@jourrapide.com','adb8eaa8c58c0f40e8cb1bd8762de570','Nofyan Susila, A.md.','0838555978',7,0,61,'2020-04-05 13:13:34',NULL,NULL,'198311222009121002','198311222009121002_20200405011334.jpg',16,55,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(154,'Supriono@jourrapide.com','adb8eaa8c58c0f40e8cb1bd8762de570','Supriono, S.h.','0878555934',7,0,61,'2020-04-05 13:15:15',NULL,NULL,'197311091996031001','197311091996031001_20200405011515.jpeg',16,56,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(155,'adityadwi@jourrapide.com','adb8eaa8c58c0f40e8cb1bd8762de570','Aditya Dwi Hartanto, S.e.','0856555371',7,0,61,'2020-04-05 13:16:55',NULL,NULL,'198305042005021001','198305042005021001_20200405011655.jpeg',16,56,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(156,'bayuartiyoso@jourrapide.com','adb8eaa8c58c0f40e8cb1bd8762de570','Bayu Artiyoso Mandiri, S.t.','0899555884',7,0,61,'2020-04-05 13:24:49',NULL,NULL,'198105242007121002','198105242007121002_20200405012449.jpeg',16,56,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(157,'akhmadrizkiansah@jourrapide.com','adb8eaa8c58c0f40e8cb1bd8762de570','Akhmad Rizkiansah, S.kom.','0853555435',7,0,61,'2020-04-05 13:26:21',NULL,NULL,'198003012010121001','198003012010121001_20200405012621.jpeg',16,56,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(158,'pandu123@dib.biz.id','8acf7115033fa7bbfebe4b9b726ab374','Rahmadi Fandu','0832173989',7,1,61,'2020-04-05 11:56:38',61,'2020-04-25 06:14:08','31263812361','31263812361_20200405115638.jpeg',16,54,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(159,'david123@dib.biz.id','172522ec1028ab781d9dfd17eaca4427','David','7387892719827',7,1,61,'2020-04-05 12:09:59',61,'2020-04-25 06:11:54','12791827812','12791827812_20200405120959.jpeg',16,53,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(160,'yogi.yulianto@students.amikom.ac.id','7815696ecbf1c96e6894b779456d330e','David Rigan','08975456789',7,1,61,'2020-04-14 16:43:55',61,'2020-04-25 06:11:19','12345678912345','12345678912345_20200414044355.png',16,43,'YY180707','Cilacap','1998-10-10','SMA','2010-10-10','laki-laki'),(161,'adittttt@dib.biz.id','486b6c6b267bc61677367eb6b6458764','Adit','089776545678',7,1,61,'2020-04-17 11:18:16',61,'2020-04-24 10:31:41','1267153127523','1267153127523_20200417111816.jpg',16,54,'SDAS343','Cilacap','1996-08-11','S3','2010-10-10','laki-laki'),(162,'sada@dsd.com','47bce5c74f589f4867dbd57e9ca9f808','Adsasd','2131414123123',7,1,61,'2020-04-24 10:29:49',61,'2020-04-24 10:31:28','12312124124124','12312124124124_20200424102949.jpg',16,16,'dfds21','12313','2020-04-25','','2020-04-16','laki-laki'),(163,'bb@dib.biz.id','08f8e0260c64418510cefb2b06eee5cd','Bb','0092173812793',7,1,61,'2020-04-24 22:37:34',61,'2020-04-24 22:37:45','123821739283','123821739283_20200424103734.jpg',16,51,'djh23','sdsd','2020-04-24','SMP','2020-04-25','laki-laki'),(164,'laluwahyu@gustr.com','adb8eaa8c58c0f40e8cb1bd8762de570','Lalu Wahyu Efendi, S.sos','0878555654',18,0,61,'2020-04-27 01:27:46',61,'2020-04-28 19:38:30','197903072002121002','197903072002121002_20200427012746.jpeg',NULL,60,'123','a','1976-02-03','','2019-01-01','laki-laki'),(165,'AminYahya@gustr.com','adb8eaa8c58c0f40e8cb1bd8762de570','Amin Yahya','0838555694',7,0,61,'2020-04-27 01:32:08',NULL,NULL,'196511211987031001','196511211987031001_20200427013208.jpeg',NULL,62,'123','a','1986-03-19','D3','2018-07-18','laki-laki'),(166,'AsnawiSuroso@gustr.com','adb8eaa8c58c0f40e8cb1bd8762de570','Asnawi Suroso,s.i.kom','0899555230',7,0,61,'2020-04-27 01:37:01',NULL,NULL,'197810032007121001','197810032007121001_20200427013701.jpeg',NULL,63,'123','a','1982-03-19','','2018-11-15','laki-laki'),(167,'Mujiono@gustr.com','adb8eaa8c58c0f40e8cb1bd8762de570','Mujiono','0858555938',7,0,61,'2020-04-27 01:41:59',NULL,NULL,'196601031989031002','196601031989031002_20200427014159.jpeg',NULL,64,'123','a','1978-02-15','','2017-07-06','laki-laki'),(168,'TeguhHadiPrasetyo@gustr.com','adb8eaa8c58c0f40e8cb1bd8762de570','Teguh Hadi Prasetyo, S.sos.','0852555896',7,0,61,'2020-04-27 01:56:45',NULL,NULL,'198103162008121002','198103162008121002_20200427015645.jpeg',NULL,66,'123','a','1978-06-09','','2019-08-30','laki-laki'),(169,'PriyoPrayudhaUtama@gustr.com','adb8eaa8c58c0f40e8cb1bd8762de570','Priyo Prayudha Utama','0878555191',7,0,61,'2020-04-27 02:00:14',NULL,NULL,'199105262009122003','199105262009122003_20200427020014.jpeg',NULL,67,'123','a','1984-08-09','','2017-09-20','laki-laki'),(170,'MorgenHidayat@gustr.com','adb8eaa8c58c0f40e8cb1bd8762de570','Morgen Hidayat','0878555337',7,0,61,'2020-04-27 02:10:28',NULL,NULL,'19841125200912100','19841125200912100_20200427021028.jpeg',NULL,45,'123','a','1990-01-14','','2019-12-21','laki-laki'),(171,'Suryanto@gustr.com','adb8eaa8c58c0f40e8cb1bd8762de570','Suryanto','0896555724',7,0,61,'2020-04-27 02:17:02',NULL,NULL,'198912262010121002','198912262010121002_20200427021702.jpeg',NULL,45,'123','a','1981-06-16','D3','2017-03-16','laki-laki'),(172,'TeguhRistanto@gustr.com','adb8eaa8c58c0f40e8cb1bd8762de570','Teguh Ristanto','0898555430',7,0,61,'2020-04-27 02:22:47',NULL,NULL,'199106132010121001','199106132010121001_20200427022247.jpeg',NULL,45,'123','a','1979-08-10','D3','2014-08-15','laki-laki'),(173,'GregoriusPurwoko@gustr.com','adb8eaa8c58c0f40e8cb1bd8762de570','Gregorius Purwoko Budi S','0878555217',7,0,61,'2020-04-27 02:29:31',NULL,NULL,'198305282010121002','198305282010121002_20200427022931.jpeg',NULL,68,'123','a','1989-03-02','D3','2011-12-31','laki-laki'),(174,'rubin@thebudhound.com','adb8eaa8c58c0f40e8cb1bd8762de570','Penilai','0921092019',19,0,61,'2020-06-07 21:44:14',174,'2020-06-24 02:22:20','234324242525','234324242525_20200624022144.jpeg',NULL,12,'KK231','Semarang','2020-06-01','D2','2020-06-09','laki-laki'),(175,'niedermachend@mealaroc.cf','887df2ff16b06f98a02cf519b6aceda1','Nieder','03287923862',7,1,61,'2020-06-10 16:32:03',174,'2020-06-10 16:55:46','0838635934','0838635934_20200610043203.jpg',16,44,'YRERHG','Cilacap','2020-06-24','D3','2020-06-10','laki-laki'),(176,'Siti55@gmail.com','e807f1fcf82d132f9bb018ca6738a19f','Siti Badriah','085757353218',7,0,61,'2020-07-02 13:38:10',NULL,NULL,'199503042015032001','default.jpg',NULL,47,'B1234','Jakarta','1995-07-02','SMA','2015-07-02','perempuan');
/*!40000 ALTER TABLE `tbl_users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-07-21 14:40:02

